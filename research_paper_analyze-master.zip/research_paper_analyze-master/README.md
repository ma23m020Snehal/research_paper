pip install -r requirements.txt
streamlit run app.py